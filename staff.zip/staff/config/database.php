<?php
error_reporting(0);
session_start();
$conn=mysqli_connect("localhost","root","","staff_search") or die("Could not Connect My Sql");

?>
