<?php
if(empty($_SESSION['id'])){
	header('Location: ../index.php');
}
?>