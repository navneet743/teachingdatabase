 <div id="ezoic-pub-ad-placeholder-110">
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- google ad -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-1476310481307603"
     data-ad-slot="7754792175"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>
 <!-- Footer -->
  <footer class="py-3 bg-black footer">
    <div class="container">
      <p class="m-0 text-center text-white small">Copyright &copy; Teaching Database 2019</p>
    </div>
    <!-- /.container -->
  </footer>
 <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
